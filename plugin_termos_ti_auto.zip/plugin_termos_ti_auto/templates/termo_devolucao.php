<!-- Modelo HTML do termo de devolução -->

<p><strong>Unidade:</strong> {{unidade}}</p>
<p><strong>Colaborador:</strong> {{colaborador}} <strong>CPF:</strong> {{cpf}}</p>

<p>Estou devolvendo, nesta data, o equipamento abaixo descriminado. Estou ciente de que deverei ressarcir a companhia por danos ou partes faltantes porventura constatados no momento desta devolução.</p>

<table border="1" cellpadding="5" cellspacing="0" width="100%">
<tr>
    <th>Marca/Modelo</th><th>S.N/TAG/IMEI</th><th>Patrimônio</th><th>Observação</th>
</tr>
<tr>
    <td>{{modelo}}</td><td>{{serial}}</td><td>{{patrimonio}}</td><td>{{observacao}}</td>
</tr>
</table>

<p>{{cidade}}, {{dia}} de {{mes}} de {{ano}}</p>

<table width="100%">
<tr>
    <td>________________________________________<br>Testemunha Nome: __________ CPF: __________</td>
    <td>________________________________________<br>{{colaborador}}</td>
</tr>
</table>
