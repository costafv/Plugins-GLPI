<!-- Modelo HTML do termo de responsabilidade -->

<p><strong>Unidade:</strong> {{unidade}}</p>
<p><strong>Colaborador:</strong> {{colaborador}} <strong>CPF:</strong> {{cpf}}</p>

<p>Estou recebendo, nesta data, os equipamentos acima descriminados, comprometendo-me a:</p>

<table border="1" cellpadding="5" cellspacing="0" width="100%">
<tr>
    <th>Marca/Modelo</th><th>S.N/TAG/IMEI</th><th>Patrimônio</th><th>Observação</th>
</tr>
<tr>
    <td>{{modelo}}</td><td>{{serial}}</td><td>{{patrimonio}}</td><td>{{observacao}}</td>
</tr>
</table>

<p>{{cidade}}, {{dia}} de {{mes}} de {{ano}}</p>

<table width="100%">
<tr>
    <td>________________________________________<br>Testemunha Nome: __________ CPF: __________</td>
    <td>________________________________________<br>{{colaborador}}</td>
</tr>
</table>
