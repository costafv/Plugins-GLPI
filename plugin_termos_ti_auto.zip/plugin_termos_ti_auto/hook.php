<?php
// hook.php - registro e inicialização do plugin Termos_TI_auto

function plugin_init_termos() {
    global $PLUGIN_HOOKS;

    // Indica que o plugin é compatível com CSRF
    $PLUGIN_HOOKS['csrf_compliant']['termos'] = true;

    // Registra o menu para o plugin
    $PLUGIN_HOOKS['menu_toadd']['termos'] = ['menu' => 'plugin_termos_menu'];

    // Página de configuração (opcional, caso tenha)
    $PLUGIN_HOOKS['config_page']['termos'] = 'front/config.form.php';
}

function plugin_version_termos() {
    return [
        'name'           => 'Termos de Equipamentos',
        'version'        => '1.0.0',
        'author'         => 'Fernando Costa',
        'license'        => 'GPLv2+',
        'minGlpiVersion' => '9.5',
    ];
}

function plugin_termos_check_prerequisites() {
    if (version_compare(GLPI_VERSION, '9.5', '<')) {
        echo "GLPI 9.5 ou superior é necessário.";
        return false;
    }
    return true;
}

function plugin_termos_check_config() {
    // Retornar true se o plugin estiver configurado corretamente
    return true;
}
#