<?php
// Busca AJAX para colaboradores GLPI

include('../../../inc/includes.php');
Session::checkLoginUser();

$term = $_GET['term'] ?? '';

if (!$term) {
    echo json_encode([]);
    exit;
}

$user = new User();

// Busca usuários cujo nome ou realname contenha o termo
// Atenção: ajustar para sua base e segurança

$sql = "SELECT id, name, realname, registrationnumber, email
        FROM glpi_users 
        WHERE (name LIKE '%".addslashes($term)."%' OR realname LIKE '%".addslashes($term)."%')
        AND disabled = 0
        LIMIT 10";

$DB = new DB();

$result = $DB->query($sql);

$results = [];

while ($row = $DB->fetch_assoc($result)) {
    $label = trim($row['name'] . ' ' . $row['realname']);
    $results[] = [
        'label' => $label,
        'value' => $label,
        'cpf' => $row['registrationnumber'] ?? '',
        'email' => $row['email'] ?? ''
    ];
}

echo json_encode($results);