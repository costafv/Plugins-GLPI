<?php
// front/termos.php - interface para gerar termos com autocomplete colaborador

include('../../../inc/includes.php');
Session::checkLoginUser();

Html::header('Termos de Equipamentos', $_SERVER['PHP_SELF'], 'plugins', 'termos');
?>

<link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>

<script>
$(function() {
    $("#colaborador").autocomplete({
        source: "search_users.ajax.php",
        minLength: 2,
        select: function(event, ui) {
            $("#colaborador").val(ui.item.label);
            $("#cpf").val(ui.item.cpf);
            $("#email").val(ui.item.email);
            return false;
        }
    });
});
</script>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dados = [
        'unidade'    => $_POST['unidade'] ?? '',
        'colaborador'=> $_POST['colaborador'] ?? '',
        'cpf'        => $_POST['cpf'] ?? '',
        'modelo'     => $_POST['modelo'] ?? '',
        'serial'     => $_POST['serial'] ?? '',
        'patrimonio' => $_POST['patrimonio'] ?? '',
        'observacao' => $_POST['observacao'] ?? '',
        'cidade'     => $_POST['cidade'] ?? '',
        'dia'        => date('d'),
        'mes'        => date('F'),
        'ano'        => date('Y'),
        'email'      => $_POST['email'] ?? ''
    ];

    $tipo = $_POST['tipo'] ?? 'responsabilidade';
    $send = isset($_POST['send']);

    require_once GLPI_ROOT . '/plugins/Termos_TI_auto/inc/termo.class.php';

    if ($tipo === 'responsabilidade') {
        $pdf = Termo::responsabilidade($dados);
    } else {
        $pdf = Termo::devolucao($dados);
    }

    if (!empty($_POST['itemtype']) && !empty($_POST['item_id'])) {
        Termo::salvarDocumento($pdf, "termo_{$tipo}_" . str_replace(' ', '_', $dados['colaborador']) . ".pdf", $_POST['itemtype'], $_POST['item_id']);
    }

    if ($send) {
        $assunto = "Envio de termo de equipamento - {$tipo}";
        $mensagem = "Olá {$dados['colaborador']},<br><br>Segue em anexo o termo referente ao equipamento.<br><br>Atenciosamente,<br>Equipe de TI";
        $ok = Termo::enviarEmail($dados['email'], $assunto, $mensagem, $pdf, "termo_{$tipo}.pdf");

        if ($ok) {
            Html::displayMsg("Email enviado com sucesso para {$dados['email']}.");
        } else {
            Html::displayError("Falha ao enviar e-mail.");
        }
    }

    header('Content-Type: application/pdf');
    echo $pdf;
    Html::footer();
    exit;
}

// Formulário para gerar termo
echo '<form method="POST" class="form">';
echo '<table class="tab_cadre_fixe">';

echo '<tr><th>Tipo de Termo</th><td>' . Html::select(['responsabilidade' => 'Responsabilidade', 'devolucao' => 'Devolução'], 'tipo', ['value' => 'responsabilidade']) . '</td></tr>';

$fields = [
    'unidade'    => 'Unidade',
    'colaborador'=> 'Colaborador',
    'cpf'        => 'CPF',
    'modelo'     => 'Modelo',
    'serial'     => 'S.N/TAG/IMEI',
    'patrimonio' => 'Patrimônio',
    'observacao' => 'Observação',
    'cidade'     => 'Cidade',
    'email'      => 'E-mail para envio'
];

foreach ($fields as $name => $label) {
    $readonly = ($name === 'cpf' || $name === 'email') ? 'readonly' : '';
    $required = ($name !== 'observacao') ? 'required' : '';
    $id = ($name === 'colaborador') ? 'id="colaborador"' : (($name === 'cpf') ? 'id="cpf"' : (($name === 'email') ? 'id="email"' : ''));

    echo "<tr><th>$label</th><td><input type='text' name='$name' $id $readonly $required></td></tr>";
}

echo '<tr><th>Itemtype (opcional)</th><td><input type="text" name="itemtype" placeholder="Ex: User, Computer"></td></tr>';
echo '<tr><th>Item ID (opcional)</th><td><input type="number" name="item_id"></td></tr>';
echo '<tr><th>Enviar por e-mail</th><td><input type="checkbox" name="send" value="1"></td></tr>';
echo '<tr><td colspan="2"><button type="submit" class="submit">Gerar Termo</button></td></tr>';

echo '</table></form>';

Html::footer();
?>