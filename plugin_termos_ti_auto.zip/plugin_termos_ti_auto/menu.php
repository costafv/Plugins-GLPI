<?php

function plugin_termos_menu() {
    return [
        'title' => 'Termos de Equipamentos',
        'page'  => '/plugins/Termos_TI_auto/front/termos.php',
        'icon'  => 'fas fa-file-contract',
        'permissions' => ['plugin_termos' => ['read']]
    ];
}
