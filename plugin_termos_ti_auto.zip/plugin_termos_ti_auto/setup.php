<?php
$plugin_version = [
    'name'           => 'Termos de Equipamentos',
    'version'        => '1.0.0',
    'author'         => 'Fernando Costa',
    'license'        => 'GPLv2+',
    'homepage'       => 'http://fcti.com',
    'minGlpiVersion' => '9.5',
];

function plugin_termos_check_prerequisites() {
    if (version_compare(GLPI_VERSION, '9.5', '<')) {
        echo "GLPI 9.5 ou superior é necessário.";
        return false;
    }
    return true;
}
