<?php

use PHPMailer\PHPMailer\PHPMailer;
use Dompdf\Dompdf;

class Termo {

    public static function gerarPDF($html) {
        $dompdf = new Dompdf();
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        return $dompdf->output();
    }

    public static function responsabilidade(array $dados) {
        $template = __DIR__ . '/../templates/termo_responsabilidade.php';
        $html = file_get_contents($template);
        foreach ($dados as $k => $v) {
            $html = str_replace("{{".$k."}}", htmlspecialchars($v), $html);
        }
        return self::gerarPDF($html);
    }

    public static function devolucao(array $dados) {
        $template = __DIR__ . '/../templates/termo_devolucao.php';
        $html = file_get_contents($template);
        foreach ($dados as $k => $v) {
            $html = str_replace("{{".$k."}}", htmlspecialchars($v), $html);
        }
        return self::gerarPDF($html);
    }

    public static function enviarEmail($email, $assunto, $mensagem, $pdfContent, $filename = 'termo.pdf') {
        global $CFG_GLPI;

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = $CFG_GLPI['smtp_host'];
            $mail->Port = $CFG_GLPI['smtp_port'];
            $mail->SMTPAuth = $CFG_GLPI['smtp_auth'];

            if ($CFG_GLPI['smtp_auth']) {
                $mail->Username = $CFG_GLPI['smtp_username'];
                $mail->Password = $CFG_GLPI['smtp_password'];
            }

            $mail->setFrom($CFG_GLPI['admin_email'], 'Equipe de TI');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = $assunto;
            $mail->Body = $mensagem;
            $mail->addStringAttachment($pdfContent, $filename);
            $mail->send();
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    public static function salvarDocumento($pdfContent, $filename, $itemtype = null, $items_id = null) {
        $upload_dir = GLPI_DOC_DIR . '/_uploads';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $filepath = $upload_dir . '/' . $filename;
        file_put_contents($filepath, $pdfContent);

        $doc = new Document();

        $input = [
            'name'          => $filename,
            'upload_file'   => $filename,
            'filename'      => $filename,
            'filepath'      => $filepath,
            'mime'          => 'application/pdf',
            'entities_id'   => 0,
            'users_id'      => Session::getLoginUserID(),
            'is_recursive'  => 1
        ];

        $docs_id = $doc->add($input);

        if ($docs_id && $itemtype && $items_id) {
            $doc_item = new Document_Item();
            $doc_item->add([
                'documents_id' => $docs_id,
                'itemtype'     => $itemtype,
                'items_id'     => $items_id
            ]);
        }
        return $docs_id;
    }
}
